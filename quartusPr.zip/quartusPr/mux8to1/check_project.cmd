@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "QBIN=D:\Programs\Quartus\quartus\bin64"
set "REV=%~1"
if "%REV%"=="" goto usage
if not "%REV%"=="mux8to1_schematic" if not "%REV%"=="mux8to1_ahdl" if not "%REV%"=="mux8to1_verilog" goto usage
"%QBIN%\quartus_sh.exe" --flow compile mux8to1 -c %REV%
if errorlevel 1 goto failed
"%QBIN%\quartus_map.exe" mux8to1 -c %REV% --generate_functional_sim_netlist
if errorlevel 1 goto failed
"%QBIN%\quartus_sim.exe" mux8to1 -c %REV% --mode=functional --vector_source=mux8to1_input.vwf --check_outputs=off --overwrite_waveform=off --simulation_results_format=VWF --write_settings_files=off
if errorlevel 1 goto failed
copy /y "db\%REV%.sim.vwf" "%REV%_result.vwf" >nul
if errorlevel 1 goto failed
echo.
echo Compilation and simulation completed successfully.
echo Open this result in Quartus: %REV%_result.vwf
echo Inputs were read from mux8to1_input.vwf.
echo Compare output Y with the required truth table.
pause
exit /b 0
:failed
echo.
echo Compilation or simulation failed. See the Error messages above.
pause
exit /b 1
:usage
echo Usage: check_project.cmd mux8to1_schematic
pause
exit /b 2
