"""Check actual Quartus results for all 2048 input combinations and the demo."""
from pathlib import Path
import re

def intervals(block):
    pattern = re.compile('NODE\\s*\\{|REPEAT\\s*=\\s*(\\d+)\\s*;|LEVEL\\s+([01X])\\s+FOR\\s+([\\d.eE+-]+)\\s*;|\\}')
    stack = [(1, [])]
    for token in pattern.finditer(block):
        value = token.group(0)
        if value.startswith('NODE'):
            stack.append((1, []))
        elif token.group(1) is not None:
            stack[-1] = (int(token.group(1)), stack[-1][1])
        elif token.group(2) is not None:
            stack[-1][1].append((token.group(2), float(token.group(3))))
        elif value == '}' and len(stack) > 1:
            count, items = stack.pop()
            stack[-1][1].extend(items * count)
    assert len(stack) == 1
    return stack[0][1]

root=Path(__file__).resolve().parent
names=list('ABC')+[f'D{n}' for n in range(8)]+['Y']
for rev in ('schematic','ahdl','verilog'):
    for mode,count,step in [('exhaustive',2048,10),('demo',16,100)]:
        source=(root/'verification'/f'mux8to1_{rev}.{mode}.sim.vwf').read_text(encoding='utf-8')
        channels={}
        for name in names:
            match=re.search(r'TRANSITION_LIST\("'+re.escape(name)+r'"\)\s*\{(.*?)(?=\n(?:TRANSITION_LIST|DISPLAY_LINE|TIME_BAR)|\Z)',source,re.S)
            assert match,name
            spans=intervals(match.group(1))
            assert abs(sum(duration for _,duration in spans)-count*step)<0.001
            pointer=0
            end=spans[0][1]
            values=[]
            for n in range(count):
                while n*step+step/2>=end:
                    pointer+=1
                    assert pointer<len(spans),(name,n)
                    end+=spans[pointer][1]
                assert spans[pointer][0] in ('0','1'),(name,n,spans[pointer][0])
                values.append(int(spans[pointer][0]))
            channels[name]=values
        for n in range(count):
            address=4*channels['A'][n]+2*channels['B'][n]+channels['C'][n]
            data=sum(channels[f'D{j}'][n]<<j for j in range(8))
            if mode=='exhaustive':
                assert address==n>>8,(rev,n,address)
                assert data==n&255,(rev,n,data)
            else:
                assert address==n%8,(rev,n,address)
                assert data==(0xA5 if n<8 else 0x5A),(rev,n,data)
            expected=(data>>address)&1
            assert channels['Y'][n]==expected,(rev,mode,n,address,data,channels['Y'][n],expected)
        print(f'PASS {rev} / {mode}: {count} cases; Y equals the selected data input.')
