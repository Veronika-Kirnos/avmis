// MUX 8 to 1: ABC is the address, with A as its most significant bit.
module mux8to1 (
    input wire A,
    input wire B,
    input wire C,
    input wire D0,
    input wire D1,
    input wire D2,
    input wire D3,
    input wire D4,
    input wire D5,
    input wire D6,
    input wire D7,
    output wire Y
);
    assign Y = (D0 & ~A & ~B & ~C)
             | (D1 & ~A & ~B & C)
             | (D2 & ~A & B & ~C)
             | (D3 & ~A & B & C)
             | (D4 & A & ~B & ~C)
             | (D5 & A & ~B & C)
             | (D6 & A & B & ~C)
             | (D7 & A & B & C);
endmodule
