@echo off
call "%~dp0check_project.cmd" mux8to1_schematic
