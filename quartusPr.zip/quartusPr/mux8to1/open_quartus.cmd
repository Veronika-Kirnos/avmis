@echo off
setlocal
cd /d "%~dp0"
start "" "D:\Programs\Quartus\quartus\bin64\quartus.exe" "%~dp0mux8to1.qpf" -c mux8to1_schematic
