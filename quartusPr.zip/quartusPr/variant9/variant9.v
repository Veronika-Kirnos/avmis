// Variant 9: Y = CD(A+B) + AB(C+D).
module variant9 (
    input wire A,
    input wire B,
    input wire C,
    input wire D,
    output wire Y
);
    assign Y = (C & D & (A | B)) | (A & B & (C | D));
endmodule
