"""Verify all 16 input words in actual Quartus results, including nested REPEAT nodes."""
from pathlib import Path
import re

def intervals(block):
    pattern=re.compile(r'NODE\s*\{|REPEAT\s*=\s*(\d+)\s*;|LEVEL\s+([01X])\s+FOR\s+([\d.eE+-]+)\s*;|\}')
    stack=[(1,[])]
    for token in pattern.finditer(block):
        value=token.group(0)
        if value.startswith('NODE'):
            stack.append((1,[]))
        elif token.group(1) is not None:
            stack[-1]=(int(token.group(1)),stack[-1][1])
        elif token.group(2) is not None:
            stack[-1][1].append((token.group(2),float(token.group(3))))
        elif value=='}' and len(stack)>1:
            count,items=stack.pop()
            stack[-1][1].extend(items*count)
    assert len(stack)==1
    return stack[0][1]

root=Path(__file__).resolve().parent
for rev in ('schematic','ahdl','verilog'):
    source=(root/'verification'/f'variant9_{rev}.sim.vwf').read_text(encoding='utf-8')
    channels={}
    for name in 'ABCDY':
        match=re.search(r'TRANSITION_LIST\("'+name+r'"\)\s*\{(.*?)(?=\n(?:TRANSITION_LIST|DISPLAY_LINE|TIME_BAR)|\Z)',source,re.S)
        assert match, name
        spans=intervals(match.group(1))
        assert abs(sum(duration for _,duration in spans)-1600)<0.001
        values=[]
        for i in range(16):
            sample=i*100+50
            end=0.0
            for level,duration in spans:
                end+=duration
                if sample<end:
                    values.append(level)
                    break
            else:
                raise AssertionError((name,sample))
        channels[name]=values
    for i in range(16):
        inputs=''.join(channels[name][i] for name in 'ABCD')
        assert inputs==f'{i:04b}',(rev,i,inputs)
        expected='1' if i in (7,11,13,14,15) else '0'
        assert channels['Y'][i]==expected,(rev,inputs,channels['Y'][i],expected)
    print(f'PASS {rev}: actual Quartus waveforms match all 16 truth table rows.')
