onerror {exit -code 1}
vlib work
vlog -work work variant9_schematic.vo
vlog -work work variant9_input.vwf.vt
vsim -novopt -c -t 1ps -L maxii_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.variant9_vlg_vec_tst -voptargs="+acc"
vcd file -direction variant9.msim.vcd
vcd add -internal variant9_vlg_vec_tst/*
vcd add -internal variant9_vlg_vec_tst/i1/*
run -all
quit -f
