library verilog;
use verilog.vl_types.all;
entity variant9_vlg_check_tst is
    port(
        Y               : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end variant9_vlg_check_tst;
