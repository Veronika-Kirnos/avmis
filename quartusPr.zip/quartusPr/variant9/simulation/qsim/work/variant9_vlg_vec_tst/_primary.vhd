library verilog;
use verilog.vl_types.all;
entity variant9_vlg_vec_tst is
end variant9_vlg_vec_tst;
